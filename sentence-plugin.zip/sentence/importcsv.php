<div class="wrap">
<h1>Import CSV</h1>
<?php
global $wpdb;
$data = array();
 
function add_data($first){
	global $data; 
	$data []= array(
		'first' => $first
	);
}
 
if ($_FILES['file']['tmp_name']){
	$dom = DOMDocument::load($_FILES['file']['tmp_name']);
	$rows = $dom->getElementsByTagName('Row');
	$first_row = true;
	$language= $_POST["language"];
	//echo $language;
	//print_r($dom->getElementsByTagName('Cell'));
	foreach ($rows as $row){
		if (!$first_row){
			$first = "";			 
			$index = 1;
			//echo $row; die;
			$cells = $row->getElementsByTagName('Cell');
			//print_r($cells);
			foreach( $cells as $cell ){ 
				$ind = $cell->getAttribute('Index');
				if ($ind != null) $index = $ind;
				 
				if ($index == 1) $first = $cell->nodeValue;
				$import_data=explode(";",$first);
				//echo $import_data['0'];
				$ss=addslashes($import_data['3']);
				$sents=$wpdb->get_results("select * from tbl_sentence where language='".$language."' and word='".$import_data['0']."' and sentence='".$ss."'");
				
				if($wpdb->num_rows==0){
				$wpdb->insert('tbl_sentence', array(
					'language'=>$language,
					'word'=>$import_data['0'],
					'url'=>$import_data['1'],
					'author'=>$import_data['2'],
					'sentence'=>$import_data['3']
				));
				}
				$index += 1;
			}
			add_data($first);
		}
		$first_row = false;
	}	
}
$languages=$wpdb->get_results("SELECT * FROM tbl_language");
?>
<form enctype="multipart/form-data" method="post">
	<table>
		<tr>
			<td>Language</td>
			<td>
				<select name="language">
				<?php
					foreach($languages as $language){
				?>
					<option <?php if($language->language_id == $sentence->language){echo"selected";} ?> value="<?php echo $language->language_id; ?>"><?php echo $language->language; ?></option>
				<?php
					}
				?>
				</select>
			</td>
		</tr>
	    <tr>
		    <td>Names file:</td>
		    <td><input type="file" name="file" /></td>
	    </tr>
		<tr>
		    <td colspan="2"><input type="submit" value="Upload" /></td>
	  </tr>
	</table>
 </form>
</div>