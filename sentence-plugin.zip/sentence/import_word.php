<div class="wrap">
<h1>Import Word</h1>
<?php
global $wpdb;
$data = array();

function add_data($first){
	global $data; 
	$data []= array(
		'first' => $first
	);
}
 
if ($_FILES['file']['tmp_name']){
	$dom = DOMDocument::load($_FILES['file']['tmp_name']);
	$rows = $dom->getElementsByTagName('Row');
	//$first_row = true;
	$language= $_POST["language"];
	foreach ($rows as $row){
		//if (!$first_row){
			$first = "";			 
			$index = 1;
			$cells = $row->getElementsByTagName('Cell');
			foreach( $cells as $cell ){ 
				$ind = $cell->getAttribute('Index');
				if ($ind != null) $index = $ind;
				 
				if ($index == 1) $first = $cell->nodeValue;
				$import_data=explode(";",$first);
				if(!isset($import_data[1])){
					$import_data[1] = "";
				}
				$positions=$wpdb->get_row("select * from tbl_word where position='".$import_data[1]."' limit 1"); 
				$pos_count=$wpdb->num_rows;
				if($pos_count>0){
					$pos_name=$positions->position_name;
				}else{
					$pos_name="";
				}
				
				$count_word=$wpdb->get_results("select * from tbl_word where word='".$import_data[0]."' and position='".$import_data[1]."' and language='".$_POST['language']."'");
					$cnt=count($count_word);
					if($cnt==0){
						$count_word=$wpdb->get_results("select * from tbl_word where word='".$import_data[0]."' and language='".$_POST['language']."'");
						$cnt=count($count_word);
						if($cnt==0){
							$wpdb->insert('tbl_word', array(
								'word'=>$import_data[0],
								'position' => $import_data[1],
								'language'=>$_POST['language'],
								'position_name'=>$pos_name
							));
						}else{
							if($import_data[0]!==''){
								$wpdb->insert('tbl_word', array(
									'word'=>$import_data[0],
									'position' => $import_data[1],
									'language'=>$_POST['language'],
									'position_name'=>$pos_name
								));
							}
						}
					}
				$index += 1;
			}
			add_data($first);
		//}
		//$first_row = false;
	}	
}
$languages=$wpdb->get_results("SELECT * FROM tbl_language");
?>
<form enctype="multipart/form-data" method="post">
	<table>
		<tr>
			<td>Language</td>
			<td>
				<select name="language">
				<?php
					foreach($languages as $language){
				?>
					<option <?php if($language->language_id == $sentence->language){echo"selected";} ?> value="<?php echo $language->language_id; ?>"><?php echo $language->language; ?></option>
				<?php
					}
				?>
				</select>
			</td>
		</tr>
	    <tr>
		    <td>Word file:</td>
		    <td><input type="file" name="file" /></td>
	    </tr>
		<tr>
		    <td colspan="2"><input type="submit" value="Upload" /></td>
		</tr>
	</table>
 </form>
</div>