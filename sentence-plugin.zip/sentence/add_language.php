<style>
.wSelect-option-icon{
    background-size: cover;
    height: 21px;
    width: 13px;
    border-radius: 100%;
    margin: 4px;
	width: 21px;
    background-position:center !important;
	
	}
</style>
<script type="text/javascript" src="js/jquery.1.10.2.min.js"></script>
<?php 
global $wpdb;
if(isset($_POST["submit"])){
	$results = $wpdb->get_row( 'SELECT * FROM tbl_language WHERE language_id = '.$_POST["language"]);
	if(count($results)=='0'){
		$wpdb->insert('tbl_language', array(
			'language_id' => $_POST["language"],
			'language' => $_POST["language"],
			'flag' =>  $_POST["flag"]
		));
	}else{
		echo $_POST["language"]." alredy in database";
	}
}

if(isset($_POST["update"])){
	 $wpdb->update( 
        'tbl_language', 
        array( 
            'language' => $_POST["language"],
			'flag' =>  $_POST["flag"]
        ),
		array('language_id' => $_POST["language_id"])
    );
}
if(isset($_GET['edit']) && isset($_GET['id'])){
	$results = $wpdb->get_results( 'SELECT * FROM tbl_language WHERE language_id = "'.$_GET['id'].'"');
}
?>
<div class="wrap">
<h1>Add New Language</h1>
</div>

<form method="post">
<table style="margin-top:10px;">
<tr>
<td>Language :</td>
<td><input type="text" value="<?php if(isset($_GET['id'])){ echo $results[0]->language; }?>" name="language" placeholder="Language" style="width:400px;"/></td>
</tr>
<tr>
<td>Flag :</td>
<td>
<select id="demo" name="flag">
<?php $dir="http://petergraae.com/petergraae.com/wp-content/uploads/flag/"; ?>
<option value="ad.png" data-icon="<?php echo $dir; ?>ad.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "ad.png"){ echo "selected='selected'"; } } ?> ></option>
<option value="ae.png" data-icon="<?php echo $dir; ?>ae.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "ae.png"){ echo "selected='selected'"; } } ?> ></option>
<option value="af.png" data-icon="<?php echo $dir; ?>af.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "af.png"){ echo "selected='selected'"; } } ?> ></option>
<option value="ag.png" data-icon="<?php echo $dir; ?>ag.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "ag.png"){ echo "selected='selected'"; } } ?> ></option>
<option value="ai.png" data-icon="<?php echo $dir; ?>ai.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "ai.png"){ echo "selected='selected'"; } } ?>></option>
<option value="al.png" data-icon="<?php echo $dir; ?>al.png" <?php if(isset($_GET['id'])){ if($results[0]->flag == "al.png"){ echo "selected='selected'"; } } ?> ></option>
</select>
</td>
</tr>
<tr>
<td colspan="2">
<?php
if(isset($_GET['id'])){
?>
<input type="hidden" name="language_id" value="<?php echo $results[0]->language_id; ?>"/>
<input type="submit" name="update" value="Save">
<?php
}else{
?>
<input type="submit" name="submit" value="Save">
<?php	
}
?>
</td>	
</tr>	
</table>	
</form>
	<link rel="Stylesheet" type="text/css" href="css/wSelect.css" />
      <script type="text/javascript" src="js/wSelect.min.js"></script>
	  <script type="text/javascript">
        $('select').wSelect();

        $('#demo, #demo-multi').change(function() {
          console.log($(this).val());
        });

        $('#demo').val('AU').change(); // should see in console
        $('#demo').val('PL').wSelect('change'); // should see the selected option change to three
        //$('#demo').append('<option value="US" data-icon="./img/US.png">United States of America</option>').wSelect('reset');
        $('#demo').val('CA').change();
        
        $('#demo-multi').val(['soccer', 'archery']).change();

        // Testing append from one select to another.
        $('#demo option:last').appendTo('#demo-multi');
        $('#demo, #demo-multi').wSelect('reset');
      </script>