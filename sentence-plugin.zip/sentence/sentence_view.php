<?php
global $wpdb;
if(isset($_GET['delete']) && isset($_GET['id'])){
		$wpdb->delete( 'tbl_sentence', array( 'sentence_id' => $_GET["id"]) );
}

	if(isset($_POST['delete']) && isset($_POST['check_id'])){
		if($_POST['action']=="trash" || $_POST['action1']=="trash"){
			foreach($_POST['check_id'] as $id){
				$wpdb->delete( 'tbl_sentence', array( 'sentence_id' => $id));
			}
		}
		
	}
	
	$sort="desc";
	if($_POST['search']!==""){
		$serch='%'.$_POST['search'].'%';
	}else{
		$serch='%';
	}
	
	
	if(isset($_POST['language_filter_by']) && $_POST['language_filter_by']!='%'){
		$language_filter_by='and tbl_sentence.language="'.$_POST["language_filter_by"].'"';
		
	}else{
		$language_filter_by='';
	}
	
	if(isset($_POST['filter_by'])){
		if($_POST['filter_by']=='dislike'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by dislike_count desc");
		}else{
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by like_count desc");
		}
	}else if(isset($_GET['sort']) && isset($_GET['sort_type'])){
		$sort=$_GET['sort'];
		if($_GET['sort_type'] =='word'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by word ".$sort);
		}else if($_GET['sort_type'] =='sentence'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by sentence ".$sort);
		}else if($_GET['sort_type'] =='author'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by author ".$sort);
		}else if($_GET['sort_type'] =='like'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by like_count ".$sort);
		}else if($_GET['sort_type'] =='language'){
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."') order by tbl_language.language ".$sort);
		}else{
			$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and  (word like '".$serch."' or sentence like '".$serch."') order by dislike_count ".$sort);
		}
		
		if($sort=="asc"){
			$sort="desc";
		}else{
			$sort="asc";
		}
		
	}else{
		$sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence,tbl_language where tbl_sentence.language=tbl_language.language_id ".$language_filter_by." and (word like '".$serch."' or sentence like '".$serch."')");
	}
	
	
	//$sentences = $wpdb->get_results( "select * from tbl_sentence where word like '".$serch."' or sentence like '".$serch."'");
	$rowcount = $wpdb->num_rows;
?>

<div class="wrap">
<form method="post">
<h1>Sentence <a href="admin.php?page=add_sentence" class="page-title-action">Add New</a> <a href="admin.php?page=importcsv" class="page-title-action">Import</a> <a href="http://petergraae.com/petergraae.com/wp-content/plugins/sentence/export.php" class="page-title-action">Export</a></h1>
	<ul class="subsubsub">
		<li class="all"><a href="edit.php?post_type=page" class="current">All <span class="count">(3)</span></a> |</li>
		<li class="publish"><a href="edit.php?post_status=publish&amp;post_type=page">Published <span class="count">(3)</span></a></li>
	</ul>
	<p class="search-box">
		<label class="screen-reader-text" for="post-search-input">Search Pages:</label>
		<input type="search" id="post-search-input" name="search" value="">
		<input type="submit" id="search-submit" name="btn_serach" class="button" value="Search">
	</p>
	<div class="tablenav top">
	
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-top" class="screen-reader-text">Select bulk action</label>
		<select name="action" id="bulk-action-selector-top">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction" class="button action" value="Apply">
	</div>
	<div class="alignleft actions">
		<label for="filter-by-date" class="screen-reader-text">Filter by date</label>
		<select name="filter_by">
			<option selected value="like">Like</option>
			<option value="dislike">Dis-Like</option>
		</select>
		<input type="submit" name="filter_action" id="post-query-submit" class="button" value="Filter">		
	</div>
	<div class="alignleft actions">
		<label for="filter-by-date" class="screen-reader-text">Filter by date</label>
		<select name="language_filter_by">
			<option value="%">Select Language</option>
			<?php 
				$languages_results=$wpdb->get_results("select * from tbl_language order by language");
				foreach($languages_results as $languages_result){
			?>
			<option value="<?php echo $languages_result->language_id; ?>"><?php echo $languages_result->language; ?></option>
			<?php
				}
			?>
			
		</select>
		<input type="submit" name="language_filter_action" id="post-query-submit" class="button" value="Filters">		
	</div>
	<div class="tablenav-pages one-page"><span class="displaying-num"><?php echo $rowcount; ?> items</span>
		<span class="pagination-links"><span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging"><span class="tablenav-paging-text"> of <span class="total-pages">1</span></span></span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span></span>
	</div>
	<br class="clear">
</div>

<table class="wp-list-table widefat fixed striped pages">
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=word">
					<span>Word</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=sentence">
					<span>Sentence</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=language">
					<span>Language</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<!--
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>News Paper</span><span class="sorting-indicator"></span>
				</a>
			</th>-->
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=author">
					<span>Author</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=like">
					<span>Like</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=dislike">
					<span>Dis-Like</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">				
					<span>Position</span><span class="sorting-indicator"></span>			
			</th>
		</tr>
	</thead>
	<tbody>
	<?php
		foreach($sentences as $sentence){
	?>
		<tr id="post-2" class="iedit author-self level-0 post-2 type-page status-publish hentry">
			<th scope="row" class="check-column">
				<label class="screen-reader-text" for="cb-select-2">Select Sample Page</label>
				<input id="cb-select-2" type="checkbox" name="check_id[]" value="<?php echo $sentence->sentence_id; ?>">
				<div class="locked-indicator"></div>
			</th>
			<td class="title column-title has-row-actions column-primary page-title">
				<strong>
				<a class="row-title" href="#" >
					<?php echo $sentence->word; ?>
				</a>
				</strong>
				<div class="row-actions">
					<span class="edit">
						<a href="admin.php?page=add_sentence&edit=1&id=<?php echo $sentence->sentence_id; ?>" aria-label="Edit �Sample Page�">Edit</a> | 
					</span>
					<span class="trash">
						<a href="admin.php?page=sentence_view&delete=1&id=<?php echo $sentence->sentence_id; ?>" onclick="return confirm('Are you sure?');" class="submitdelete" aria-label="Move �Sample Page� to the Trash" onclick="return confirm('Are you sure?');" >Trash</a> | 
					</span>
					
				</div>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $sentence->sentence; ?>
				</a>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $sentence->language; ?>
				</a>
			</td>
			<!--
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $sentence->news_paper; ?>
				</a>
			</td>-->
			
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $sentence->author; ?>
				</a>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php
					echo $sentence->like_count;
						// $like=$wpdb->get_results( "select * from tbl_counter where sentence_id='".$sentence->sentence_id."' and status='1'");
						// echo count($like);
					?>
				</a>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php 
					echo $sentence->dislike_count;
						// $dis_like=$wpdb->get_results( "select * from tbl_counter where sentence_id='".$sentence->sentence_id."' and status='2'");
						// echo count($dis_like);
					?>
				</a>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php 
					echo $sentence->word_position;
						// $dis_like=$wpdb->get_results( "select * from tbl_counter where sentence_id='".$sentence->sentence_id."' and status='2'");
						// echo count($dis_like);
					?>
				</a>
			</td>
		</tr>
	<?php
		}
	?>
	</tbody>
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=word">
					<span>Word</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=sentence">
					<span>Sentence</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=language">
					<span>Language</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<!--
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>News Paper</span><span class="sorting-indicator"></span>
				</a>
			</th>
			-->
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=author">
					<span>Author</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=like">
					<span>Like</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=sentence_view&sort=<?php echo $sort; ?>&sort_type=dislike">
					<span>Dis-Like</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">				
					<span>Position</span><span class="sorting-indicator"></span>			
			</th>
		</tr>
	</thead>
</table>
<div class="tablenav bottom">
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-bottom" class="screen-reader-text">Select bulk action</label>
		<select name="action1" id="bulk-action-selector-bottom">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction2" class="button action" value="Apply">
	</div>
</form>
	<div class="alignleft actions"></div>
<div class="tablenav-pages one-page">
	<span class="displaying-num"><?php echo $rowcount; ?> items</span>
	<span class="pagination-links">
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="screen-reader-text">Current Page</span>
		<span id="table-paging" class="paging-input">
			<span class="tablenav-paging-text">1 of <span class="total-pages">1</span></span>
		</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
	</span>
</div>
		<br class="clear">
</div>
</form>
</div>