<?php
global $wpdb;
function include_media_button_js_file() {
    wp_enqueue_script('media_button', 'path/to/media_button.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_media', 'include_media_button_js_file');

if(isset($_POST['submit'])){
	$table = 'tbl_ads';
	$image_size = array(getimagesize($_POST['image-url'])[0],getimagesize($_POST['image-url'])[1]);
	$position = $_POST['position'];
	if($position == 1)
	{
		$require_size = array('728','120');
		$message = "728 x 128";
	}
	else if($position == 2)
	{
		$require_size = array('300','250');
		$message = "300 X 250";
	}
	else if($position == 3)
	{
		$require_size = array('300','600');
		$message = "300 X 600";
	}
	else if($position == 4)
	{
		$require_size = array('300','250');
		$message = "300 X 250";
	}
	else if($position == 5)
	{
		$require_size = array('300','600');
		$message = "300 X 600";
	}
	if($image_size != $require_size)
	{
		echo "<div class='alert alert-danger'>You Must be Upload image in <strong>".$message."</strong> size </div>";
	} else {
		$data= array(
					'image_name'	=>  $_POST['image-title'],
					'image_url'		=>	$_POST['image-url'],
					'ad_url'		=>	$_POST['ad-url'],
					'position'		=> 	$_POST['position']	
				);
		$wpdb->insert($table,$data);
	}
}

if(isset($_POST['update'])){
	$table = 'tbl_ads';
	$data= array(
				'image_name'	=>  $_POST['image-title'],
				'image_url'		=>	$_POST['image-url'],
				'ad_url'		=>	$_POST['ad-url'],
				'position'		=> 	$_POST['position']	
			);
	$where = array( 'id' => $_GET['id']);
	$wpdb->update($table,$data,$where);
	echo "<script>window.location.href = 'admin.php?page=add_ads';</script>";
}

if(isset($_GET['del_id'])){
	$table = 'tbl_ads';
	$wpdb->delete( $table, array( 'id' => $_GET['del_id'] ) );
	echo "<script>window.location.href = 'admin.php?page=add_ads';</script>";
}
?>
<style>
   #insert-my-media{
	   	border-radius: 5px;
	    background: white;
	   /* width: 10%;*/
	    padding: 3px 22px;
	    margin-left: 9px;
	    margin-top: 10px;
	    cursor: pointer;
	    outline: none;
	}
	.main-div{
		width:100%;
	}
	.col-md-2{
		width:20%;
	}
	.col-md-3{
		width:25%;
	}
	.col-md-4{
		width:;
	}
	.ad-url{
		margin-top: 10px;
	}
	.ad-url input{
		margin-left: 7px;
	}
	#show-image{
		display: none;
		margin-left: 54px;
	}
	.updated_image{
		margin-left: 54px;
	}
	.alert{
		padding: 15px;
	    margin-bottom: 20px;
	    border: 1px solid transparent;
	    border-radius: 4px;
	}
	.alert-danger {
	    color: #a94442;
	    background-color: #f2dede;
	    border-color: #ebccd1;
	}
	.submit-btn{
		background: #0073aa;
		padding: 5px 20px;
		border:1px solid #0073aa;
		color:white;
	}
	table{
		margin-top: 10px;
	}
	
</style>
<script>
	function open_media_window() {
    if (this.window === undefined) {
        this.window = wp.media({
                title: 'Insert a media',
                library: {type: 'image'},
                multiple: false,
                button: {text: 'Insert'}
            });

        var self = this; // Needed to retrieve our variable in the anonymous function below
        this.window.on('select', function() {
                var first = self.window.state().get('selection').first().toJSON();
                wp.media.editor.insert('[myshortcode id="' + first.id + '"]');
                jQuery("input[name='image-url']").val(first.url);
                jQuery("input[name='image-title']").val(first.title);
                var url = first.url;
                var position = jQuery('select[name="position"]').val(); 
               	if(position != '' && url != '')
               	{
               		if(position == 1){
               			var require_size = "728 x 128";
               		} 
               		else if(position == 2){
               			var require_size = "300 X 250";
               		}
               		else if(position == 3){
               			var require_size = "300 X 600"; 
               		}
               		else if(position == 4){
               			var require_size = "300 X 250"; 
               		}
               		else if(position == 5){
               			var require_size = "300 X 600"; 
               		}
                jQuery.ajax({
                	type:"post",
                	url:"/petergraae.com/wp-content/plugins/Ads/check-size.php",
                	cache:"false",
                	data:{url:url, pos:position},
                	success: function(response){
                		if(response == 1){
                			alert("You Must be Upload image in "+require_size+" size");
                		} else {
                			jQuery('img[name="image-src"]').attr("src",first.url);
                			jQuery("#show-image").show();
                		
                		}
                	}
                });
                }
            });
    }

    this.window.open();
    return false;
}
jQuery(function($) {
    $(document).ready(function(){
    		$('#insert-my-media').click(open_media_window);
        });
  
});

</script>
<?php  if(isset($_GET['id'])){
			$fetch = $wpdb->get_results("SELECT * FROM tbl_ads WHERE id=".$_GET['id']."");
			/*echo "<pre>"; print_r($fetch); echo"</pre>";*/
	 ?>
		<form method="post">
		<h1> Update Ads </h1>
		<div>
			Position: 
			<select name="position">
				<option value="">Select Position</option>
				<option value="1" <? if($fetch[0]->position == 1){ echo "selected"; } ?> >Top</option>
				<option value="2" <? if($fetch[0]->position == 2){ echo "selected"; } ?> >Right First</option>
				<option value="3" <? if($fetch[0]->position == 3){ echo "selected"; } ?> >Right Second</option>
				<option value="4" <? if($fetch[0]->position == 4){ echo "selected"; } ?> >Right Third</option>
				<option value="5" <? if($fetch[0]->position == 5){ echo "selected"; } ?> >Right Fourth</option>
			</select>
		</div>

		<div>
			image: 
			<input type="button" name="Add Media" value="Add Media" id="insert-my-media">
			<input type="hidden" name="image-url" value="<?= $fetch[0]->image_url; ?>">
			<input type="hidden" name="image-title" value="<?= $fetch[0]->image_name; ?>">
		</div>

		<div class="updated_image">
			<img src="<?= $fetch[0]->image_url; ?>" width="130" height="90">
		</div>

		<div class="ad-url">
			Ad Url: 
			<input type="text" name="ad-url" value="<?= $fetch[0]->ad_url;  ?>">
		</div>


		<div style="margin-top: 10px;">
			<input type="submit" class="submit-btn" name="update" value="Update">
		</div>
	</form>

		<? } else { ?>
	<form method="post">
		<h1> Add Ads </h1>
		<div>
			Position: 
			<select name="position">
				<option value="">Select Position</option>
				<option value="1">Top</option>
				<option value="2">Right First</option>
				<option value="3">Right Second</option>
				<option value="4">Right Third</option>
				<option value="5">Right Fourth</option>
			</select>
		</div>

		<div>
			image: 
			<input type="button" name="Add Media" value="Add Media" id="insert-my-media">
			<input type="hidden" name="image-url" value="">
			<input type="hidden" name="image-title" value="">
		</div>

		<div id="show-image">
			<img src="" name="image-src" width="130" height="90">
		</div>

		<div class="ad-url">
			Ad Url: 
			<input type="text" name="ad-url" value="">
		</div>


		<div style="margin-top: 10px;">
			<input type="submit" class="submit-btn" name="submit" value="Submit">
		</div>
	</form>
	<? } ?>

<!-- <div class="main-div">
<table border="1">
	<thead>
		<th class="col-md-2">Image Name</th>
		<th class="col-md-3">Image</th>
		<th class="col-md-3">Url</th>
		<th class="col-md-2">Position</th>
		<th class="col-md-2">Action</th>
	</thead>
	<tbody>
	<?php 
		$result = $wpdb->get_results("SELECT * FROM tbl_ads order by position");
		foreach ($result as $key) {
			if($key->position == 1){
               		$pos = "Top";
           		} 
           		else if($key->position == 2){
           			$pos = "Right First";
           		}
           		else if($key->position == 3){
           			$pos = "Right Second";
           		}
           		else if($key->position == 4){
           			$pos = "Right Third"; 
           		}
           		else if($key->position == 5){
           			$pos = "Right Fourth";
           		}
	 ?>
		<tr>
			<td><?= $key->image_name; ?></td>
			<td><img src="<?= $key->image_url; ?>" width="130" height="90"></td>
			<td><?= $key->ad_url; ?></td>
			<td><?= $pos; ?></td>
			<td><a href="admin.php?page=add_ads&id=<?= $key->id; ?>">Edit</a> | <a href="admin.php?page=add_ads&del_id=<?= $key->id; ?>" onclick="return confirm('Are you sure?');">Delete</a></td>
		</tr>
		<?	} ?>
	</tbody>
</table>
</div> -->
<?
if($_POST['search']!==""){
		$serch='%'.$_POST['search'].'%';
	}else{
		$serch='%';
	}
 $result = $wpdb->get_results("SELECT * FROM tbl_ads where image_name like '".$serch."' order by position"); ?>
<form method="post" style="width:98.5%">
<h1> <!-- <a href="admin.php?page=add_sentence" class="page-title-action">Add New</a> --> </h1>
	<ul class="subsubsub">
		<li class="all"><a href="edit.php?post_type=page" class="current">All <span class="count">(<?= count($result); ?>)</span></a> |</li>
		<li class="publish"><a href="edit.php?post_status=publish&amp;post_type=page">Published <span class="count">(<?= count($result); ?>)</span></a></li>
	</ul>
	<p class="search-box">
		<label class="screen-reader-text" for="post-search-input">Search Pages:</label>
		<input type="search" id="post-search-input" name="search" value="">
		<input type="submit" id="search-submit" name="btn_serach" class="button" value="Search">
	</p>
	<div class="tablenav top">
	
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-top" class="screen-reader-text">Select bulk action</label>
		<select name="action" id="bulk-action-selector-top">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction" class="button action" value="Apply">
	</div>
	
	<div class="tablenav-pages one-page"><span class="displaying-num"><?php echo count($result); ?> items</span>
		<span class="pagination-links"><span class="tablenav-pages-navspan" aria-hidden="true">«</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">‹</span>
		<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging"><span class="tablenav-paging-text"> of <span class="total-pages">1</span></span></span>
		<span class="tablenav-pages-navspan" aria-hidden="true">›</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">»</span></span>
	</div>
	<br class="clear">
</div>

<table class="wp-list-table widefat fixed striped pages">
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Image Name</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Image</span><span class="sorting-indicator"></span>
				</a>
			</th>
			
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Url</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Position</span><span class="sorting-indicator"></span>
				</a>
			</th>
			
		</tr>
	</thead>
	<tbody>
	<?php

		foreach($result as $key){
			if($key->position == 1){
           		$pos = "Top";
       		} 
       		else if($key->position == 2){
       			$pos = "Right First";
       		}
       		else if($key->position == 3){
       			$pos = "Right Second";
       		}
       		else if($key->position == 4){
       			$pos = "Right Third"; 
       		}
       		else if($key->position == 5){
       			$pos = "Right Fourth";
       		}
	?>
		<tr id="post-2" class="iedit author-self level-0 post-2 type-page status-publish hentry">
			<th scope="row" class="check-column">
				<label class="screen-reader-text" for="cb-select-2">Select Sample Page</label>
				<input id="cb-select-2" type="checkbox" name="check_id[]" value="<?php //echo $sentence->sentence_id; ?>">
				<div class="locked-indicator"></div>
			</th>
			<td class="title column-title has-row-actions column-primary page-title">
				<strong>
				<a class="row-title" href="#" >
					<?php echo $key->image_name; ?>
				</a>
				</strong>
				<div class="row-actions">
					<span class="edit">
						<a href="admin.php?page=add_ads&id=<?= $key->id; ?>" aria-label="Edit “Sample Page”">Edit</a> | 
					</span>
					<span class="trash">
						<a href="admin.php?page=add_ads&del_id=<?= $key->id; ?>" onclick="return confirm('Are you sure?');" class="submitdelete" aria-label="Move “Sample Page” to the Trash" onclick="return confirm('Are you sure?');" >Trash</a> | 
					</span>
					
				</div>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<img src="<?= $key->image_url; ?>" width="130" height="90">
				</a>
			</td>
			
			
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $key->ad_url; ?>
				</a>
			</td>
			
			<td class="title column-title has-row-actions column-primary page-title">
				<a class="row-title" href="#" >
					<?php echo $pos; ?>
				</a>
			</td>
			
		</tr>
	<?php
		}
	?>
	</tbody>
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Image Name</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Image</span><span class="sorting-indicator"></span>
				</a>
			</th>
			
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Url</span><span class="sorting-indicator"></span>
				</a>
			</th>

			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="#">
					<span>Position</span><span class="sorting-indicator"></span>
				</a>
			</th>
			
		</tr>
	</thead>
</table>
<div class="tablenav bottom">
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-bottom" class="screen-reader-text">Select bulk action</label>
		<select name="action1" id="bulk-action-selector-bottom">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction2" class="button action" value="Apply">
	</div>
</form-->