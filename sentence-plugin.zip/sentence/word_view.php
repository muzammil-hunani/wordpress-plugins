<?php
global $wpdb;
if(isset($_GET['del_id'])){
		$wpdb->delete( 'tbl_word', array( 'word_id' => $_GET['del_id']) );
}



	if(isset($_POST['delete']) && isset($_POST['check_id'])){
		if($_POST['action']=="trash" || $_POST['action1']=="trash"){
			foreach($_POST['check_id'] as $id){
				$wpdb->delete( 'tbl_word', array( 'word_id' => $id));
			}
		}
		
	}
	
	$sort="desc";
	if($_POST['search']!==""){
		$serch='%'.$_POST['search'].'%';
	}else{
		$serch='%';
	}
	
	if(isset($_POST['btn_serach'])){
		
			$sentences = $wpdb->get_results( "select * from tbl_word where word like '".$serch."' ");
	
			// $sentences = $wpdb->get_results( "select *,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=1) as like_count,(select count(counter_id) from tbl_counter where sentence_id=tbl_sentence.sentence_id and status=2) as dislike_count from tbl_sentence where word like '".$serch."' or sentence like '".$serch."' order by like_count desc");
	}else if(isset($_GET['sort']) && isset($_GET['sort_type'])){
		$sort=$_GET['sort'];
		if($_GET['sort_type'] =='word'){
			$sentences = $wpdb->get_results( "select * from tbl_word order by word ".$sort);
		} 
		else if($_GET['sort_type'] =='position')
		{
			$sentences = $wpdb->get_results( "select * from tbl_word order by position ".$sort);
		}
		
		if($sort=="asc"){
			$sort="desc";
		}else{
			$sort="asc";
		}
		
	}else{
		$sentences = $wpdb->get_results( "select * from tbl_word where word like '".$serch."'");
	}
	
	
	//$sentences = $wpdb->get_results( "select * from tbl_sentence where word like '".$serch."' or sentence like '".$serch."'");
	$rowcount = $wpdb->num_rows;
?>

<div class="wrap">
<form method="post">
<h1>Word <a href="admin.php?page=word_view&add=1" class="page-title-action">Add New</a> <a href="admin.php?page=import_word" class="page-title-action">Import</a> <a href="http://petergraae.com/petergraae.com/wp-content/plugins/sentence/export_word.php" class="page-title-action">Export</a></h1>
<?php 
$languages=$wpdb->get_results("SELECT * FROM tbl_language");
	if(isset($_GET['id'])){
	$get_word = $wpdb->get_results("select * from tbl_word where word_id=".$_GET['id']);
	?>
		<div>
			<form method='post'>
					<div> Word: <input type='text' name='word_field' style='margin-left: 15px;' value="<?php echo $get_word[0]->word; ?>"></div>
					<div> Position: <input type='text' name='position_field' value="<?php echo $get_word[0]->position; ?>"></div>
					<div> Language: 
						<select name="language">
							<?php
							
								foreach($languages as $language){
									
							?>
								<option <?php if($get_word[0]->language==$language->language_id){echo"selected";} ?> value="<?php echo $language->language_id; ?>"><?php echo $language->language; ?></option>
							<?php
								}
							?>
						</select>
					</div>
					<div><input type='submit' value='Update' name='update' style='background: #0073AA;color: white;padding: 2px 20px;  border: 1px solid #0073AA;  border-radius: 3px;'></div>
			</form>
		</div>
		<?php
			if(isset($_POST['word_field']))
			{
				$wpdb->update('tbl_word',array('word' => $_POST['word_field'], 'position' => $_POST['position_field'],'language'=>$_POST['language']),array('word_id' => $_GET['id']));
				echo "<script>window.location.href = 'admin.php?page=word_view'</script>";
			}
	} else if(isset($_GET['add']) && $_GET['add'] == 1){
		
		?>
		<div>
			<form method='post'>
					<div> Word: <input type='text' name='word_field' style='margin-left: 26px;'></div>
					<div> Position: <input type='text' name='position_field' style='margin-left: 12px;'></div>
					<div> Language: 
						<select name="language">
							<?php
								foreach($languages as $language){
							?>
								<option value="<?php echo $language->language_id; ?>"><?php echo $language->language; ?></option>
							<?php
								}
							?>
						</select>
					</div>
					<div><input type='submit' value='Submit' name='submit' style='background: #0073AA;color: white;padding: 2px 20px;  border: 1px solid #0073AA;  border-radius: 3px;'></div>
			</form>
		</div>
		<?php

		if(isset($_POST['word_field']) && isset($_POST['submit']))
		{
					$count_word=$wpdb->get_results("select * from tbl_word where word='".$_POST['word_field']."' and position='".$_POST['position_field']."' and language='".$_POST['language']."'");
					$cnt=count($count_word);
					if($cnt==0){
						$count_word=$wpdb->get_results("select * from tbl_word where word='".$_POST['word_field']."' and language='".$_POST['language']."'");
						$cnt=count($count_word);
						if($cnt==0){
							$wpdb->insert('tbl_word', array('word' => $_POST['word_field'], 'position' => $_POST['position_field'],'language'=>$_POST['language']));						
						}else{
							if( $_POST['position_field']!==''){
								$wpdb->insert('tbl_word', array('word' => $_POST['word_field'], 'position' => $_POST['position_field'],'language'=>$_POST['language']));
							}
						}	
						
						
						if(strlen($_POST['position_field']) > 0){
							$wpdb->delete('tbl_word',array('word' => $_POST['word_field'],'position' => ''));
						}
					}
				
				echo "<script>window.location.href = 'admin.php?page=word_view';</script>";
			}
		} ?>

	<ul class="subsubsub">
		<li class="all"><a href="edit.php?post_type=page" class="current">All <span class="count">(3)</span></a> |</li>
		<li class="publish"><a href="edit.php?post_status=publish&amp;post_type=page">Published <span class="count">(3)</span></a></li>
	</ul>
	<p class="search-box">
		<label class="screen-reader-text" for="post-search-input">Search Pages:</label>
		<input type="search" id="post-search-input" name="search" value="">
		<input type="submit" id="search-submit" name="btn_serach" class="button" value="Search">
	</p>
	<div class="tablenav top">
	
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-top" class="screen-reader-text">Select bulk action</label>
		<select name="action" id="bulk-action-selector-top">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction" class="button action" value="Apply">
	</div>
	<!-- <div class="alignleft actions">
		<label for="filter-by-date" class="screen-reader-text">Filter by date</label>
		<select name="filter_by">
			<option selected value="like">Like</option>
			<option value="dislike">Dis-Like</option>
		</select>
		<input type="submit" name="filter_action" id="post-query-submit" class="button" value="Filter">		
	</div> -->
	<div class="tablenav-pages one-page"><span class="displaying-num"><?php echo $rowcount; ?> items</span>
		<span class="pagination-links"><span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging"><span class="tablenav-paging-text"> of <span class="total-pages">1</span></span></span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span></span>
	</div>
	<br class="clear">
</div>

<table class="wp-list-table widefat fixed striped pages">
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=word_view&sort=<?php echo $sort; ?>&sort_type=word">
					<span>Word</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=word_view&sort=<?php echo $sort; ?>&sort_type=position">
					<span>Position</span><span class="sorting-indicator"></span>
				</a>
			</th>
		</tr>
	</thead>
	<tbody>
	<?php
	// echo"<pre>"; print_r($sentences); echo"</pre>";
		foreach($sentences as $sentence){
	?>
		<tr id="post-2" class="iedit author-self level-0 post-2 type-page status-publish hentry">
			<th scope="row" class="check-column">
				<label class="screen-reader-text" for="cb-select-2">Select Sample Page</label>
				<input id="cb-select-2" type="checkbox" name="check_id[]" value="<?php echo $sentence->word_id; ?>">
				<div class="locked-indicator"></div>
			</th>
			<td class="title column-title has-row-actions column-primary page-title">
				<strong>
				<a class="row-title" href="#" >
					<?php echo $sentence->word; ?>
				</a>
				</strong>
				<div class="row-actions">
					<span class="edit">
						<a href="admin.php?page=word_view&id=<?php echo $sentence->word_id; ?>" aria-label="Edit �Sample Page�">Edit</a> | 
					</span>
					<span class="trash">
						<a href="admin.php?page=word_view&del_id=<?php echo $sentence->word_id; ?>" onclick="return confirm('Are you sure?');" class="submitdelete" aria-label="Move �Sample Page� to the Trash" onclick="return confirm('Are you sure?');" >Trash</a> | 
					</span>
					
				</div>
			</td>
			<td class="title column-title has-row-actions column-primary page-title">
				<strong>
				<a class="row-title" href="#" >
					<?php echo $sentence->position; ?>
				</a>
				</strong>
			</td>
		</tr>
	<?php
		}
	?>
	</tbody>
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=word_view&sort=<?php echo $sort; ?>&sort_type=word">
					<span>Word</span><span class="sorting-indicator"></span>
				</a>
			</th>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=word_view&sort=<?php echo $sort; ?>&sort_type=position">
					<span>Position</span><span class="sorting-indicator"></span>
				</a>
			</th>
		</tr>
	</thead>
</table>
<div class="tablenav bottom">
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-bottom" class="screen-reader-text">Select bulk action</label>
		<select name="action1" id="bulk-action-selector-bottom">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction2" class="button action" value="Apply">
	</div>
</form>
	<div class="alignleft actions"></div>
<div class="tablenav-pages one-page">
	<span class="displaying-num"><?php echo $rowcount; ?> items</span>
	<span class="pagination-links">
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="screen-reader-text">Current Page</span>
		<span id="table-paging" class="paging-input">
			<span class="tablenav-paging-text">1 of <span class="total-pages">1</span></span>
		</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
	</span>
</div>
		<br class="clear">
</div>
</form>
</div>