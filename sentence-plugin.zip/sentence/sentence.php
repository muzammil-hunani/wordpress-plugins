<?php
/**
*Plugin Name: sentence
*Plugin URI: 
*Author: Nishit Manjarawala
*Author URI: 
*Version: 1.0
*/
add_action( 'admin_menu', 'register_sentence' );
function register_sentence(){	
    add_menu_page( 'Sentence', 'Sentence', '', 'Sentence', '','', 9 );
	add_submenu_page( 'Sentence', 'Sentence','Sentence', 'manage_options', 'sentence_view', 'sentence_view');
	add_submenu_page( 'Sentence', 'Add Sentence','Add Sentence', 'manage_options', 'add_sentence', 'add_sentence');
	add_submenu_page( 'Sentence', 'Word','Word', 'manage_options', 'word_view', 'word_view');
	add_submenu_page( 'Sentence', 'Word Position','Word Position', 'manage_options', 'word_position', 'word_position');
    add_submenu_page( 'Sentence', 'Languages','Languages', 'manage_options', 'language', 'language');  
	add_submenu_page( 'Sentence', 'Add_language','Add_language', 'manage_options', 'add_language', 'add_language');
	add_submenu_page( 'Sentence', 'Import csv','Import csv', 'manage_options', 'importcsv', 'importcsv');
	add_submenu_page( 'Sentence', 'Export csv','Export csv', 'manage_options', 'exportcsv', 'exportcsv');
	add_submenu_page( 'Sentence', 'Import Word','Import Word', 'manage_options', 'import_word', 'import_word');
	add_submenu_page( 'Sentence', 'Words without sentence','Words without sentence', 'manage_options', 'words_without_sentence', 'words_without_sentence');
}
function language(){
    include('language.php');
}
function add_language(){
    include('add_language.php');
}
function sentence_view(){
    include('sentence_view.php');
}
function word_view(){
    include('word_view.php');
}
function add_sentence(){
    include('add_sentence.php');
}
function importcsv(){
    include('importcsv.php');
}
function exportcsv(){
    include('exportcsv.php');
}
function import_word(){
	include('import_word.php');
}
function word_position(){
	include('word_position.php');
}
function words_without_sentence(){
	include('words_without_sentence.php');
} 
?>