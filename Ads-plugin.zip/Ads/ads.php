<?php
/**
*Plugin Name: Ads Section
*Plugin URI: 
*Author: Muzammil Navy
*Author URI: 
*Version: 1.0
*/
add_action( 'admin_menu', 'register_ads' );
function register_ads(){	
    add_menu_page( 'Ads', 'Ads', '', 'Ads', '','', 8 );
    add_submenu_page( 'Ads', 'Ads','Ads', 'manage_options', 'add_ads', 'add_ads');
	
}
function add_ads()
{
    include('add_new_ads.php');
}
?>