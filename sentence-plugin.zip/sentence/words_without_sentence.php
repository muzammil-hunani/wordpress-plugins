<?php
global $wpdb;
$words=$wpdb->get_results("select * from tbl_word,tbl_language where tbl_word.language=tbl_language.language_id group by tbl_word.word,tbl_word.language");
?>
<div class="wrap">
<h1>words without sentence</h1>
<table border='1'>
<tr>
	<th>Word</th>
	<th>Language</th>
</tr>
<?php
foreach($words as $word){
	$sentencs=$wpdb->get_row("select * from tbl_sentence where language='".$word->language."' and word='".$word->word."'");
	if(count($sentencs)=='0'){
		echo"<tr>";
			echo"<td>".$word->word."</td>";
			echo"<td>".$word->language."</td>";
		echo"</tr>";
	}
}
 ?>
 </table>
</div>