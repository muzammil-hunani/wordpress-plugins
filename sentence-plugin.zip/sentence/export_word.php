<?php
$conn = new mysqli('localhost', 'petergra_sentenc', 'mnaw-9ZoykFQ','petergra_sentence');

// global $wpdb;
// $sentences = $wpdb->get_results( "select * from tbl_counter");
// $link=mysqli_connect('localhost','petergra_sentence','mnaw-9ZoykFQ','petergra_sentence');
// $rows=array();
$data=array();
$sentences=mysqli_query($conn,"select * from tbl_word")or die(mysqli_error($conn));
while($row1=mysqli_fetch_array($sentences)){
	$rows=array($row1['word']);
	array_push($data,$rows);
} 

// foreach($sentences as $sentence){
	// $rows[]=$sentence->sentence;
// }
	//$data =array($rows);
	
	function filterData(&$str)
	{
		$str = preg_replace("/\t/", "\\t", $str);
		$str = preg_replace("/\r?\n/", "\\n", $str);
		if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
	}
	
	// file name for download
	$fileName = "petergraae" . date('Ymd') . ".xls";
	
	// headers for download
	header("Content-Disposition: attachment; filename=\"$fileName\"");
	header("Content-Type: application/vnd.ms-excel");
	
	$flag = false;
	// echo"<pre>";
	// print_r($data);
	// echo"<pre>";
	foreach($data as $row) {
		// if(!$flag) {
		//	display column names as first row
			// echo implode("\t", array_keys($row)) . "\n";
			// $flag = true;
		// }
		// filter data
		array_walk($row, 'filterData');
		echo implode("\t", array_values($row)) . "\n";
	}
	
	exit;
?>