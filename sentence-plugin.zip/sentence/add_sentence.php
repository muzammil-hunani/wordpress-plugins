<?php
global $wpdb;
if(isset($_POST['save'])){
	$wpdb->insert('tbl_sentence', array(
    'language' => $_POST["language"],
    'word' =>  $_POST["word"],
	'sentence' =>  stripslashes($_POST["sentence"]),
	'url' =>  $_POST["url"],
	//'news_paper' =>  $_POST["news_paper"],
	'author' =>  $_POST["author"]
	));
}
if(isset($_POST['update'])){
	$wpdb->update( 
        'tbl_sentence', 
        array( 
            'language' => $_POST["language"],
			'word' =>  $_POST["word"],
			'sentence' =>  stripslashes($_POST["sentence"]),
			'url' =>  $_POST["url"],
			//'news_paper' =>  $_POST["news_paper"],
			'author' =>  $_POST["author"]
        ),
		array('sentence_id' => $_POST["sentence_id"])
    );
}

$languages=$wpdb->get_results("SELECT * FROM tbl_language");
if(isset($_GET['edit']) && isset($_GET['id'])){
	$sentence=$wpdb->get_row("SELECT * FROM tbl_sentence where sentence_id=".$_GET['id']);
}
?>

<div class="wrap">
<h1>Add New Language</h1>
<form method="post">
<table>
<tr>
<td>Language</td>
<td>
	<select name="language">
	<?php
		foreach($languages as $language){
	?>
		<option <?php if($language->language_id == $sentence->language){echo"selected";} ?> value="<?php echo $language->language_id; ?>"><?php echo $language->language; ?></option>
	<?php
		}
	?>
	</select>
</td>
</tr>
<tr>
<td>Word</td>
<td>
<input type="text" name="word" value="<?php echo $sentence->word; ?>"  />
</td>
</tr>
<tr>
<td>Sentence</td>
<td>
<textarea name="sentence"><?php echo $sentence->sentence; ?></textarea>
</td>
</tr>
<tr>
<td>Url</td>
<td>
<input type="text" name="url" value="<?php echo $sentence->url; ?>"  />
</td>
</tr>
<!--
<tr>
<td>News Paper</td>
<td>
<input type="text" name="news_paper" value="<?php echo $sentence->news_paper; ?>"  />
</td>
</tr>-->
<tr>
<td>Author</td>
<td>
<input type="text" name="author" value="<?php echo $sentence->author; ?>"  />
</td>
</tr>
<tr>
<td colspan="2">
<?php
if(isset($_GET['edit']) && isset($_GET['id'])){
?>
<input type="hidden" name="sentence_id" value="<?php echo $_GET['id']; ?>"/>
<input type="submit" name="update" value="Save">
<?php
}else{
?>
	<input type="submit" name="save" value="Save">
<?php
}
?>
</td>
</tr>
</table>
</form>
</div>