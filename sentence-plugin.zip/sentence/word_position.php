<?php 
global $wpdb;
if(isset($_POST['save'])){
	$counter=0;
	$display=$_POST['display_name'];
	
	foreach($_POST['position'] as $pos){
		$wpdb->update('tbl_word', array('position_name'=>$display["$counter"]), array('position'=>$pos));
		
		//echo $display["$counter"];
		 $counter++;
	}
}
?>
<div class="wrap">
<h1>Word Position</h1>
<form method="post">
<table>
<tr>
	<td>Position</td>
	<td>Display Name</td>
</tr>
<?php 
$posisyions=$wpdb->get_results("select * from tbl_word group by position");
foreach($posisyions as $posisyion){
?>

<tr>
	<td><?php echo $posisyion->position; ?></td>
	<td>
		<input name='position[]' value="<?php echo $posisyion->position; ?>" type="hidden"/>
		<input name='display_name[]' value="<?php echo $posisyion->position_name; ?>" type="text"/>
	</td>
</tr>
<?php }
?>
<tr>
	<td colspan="2"><input type="submit" name="save" value="Save"></td>
</tr>
</table>
</form>
</div>