<?php
	global $wpdb;
	if(isset($_GET['delete']) && isset($_GET['id'])){
		$wpdb->delete( 'tbl_language', array( 'language_id' => $_GET["id"]) );
	}
	
	if(isset($_POST['delete']) && isset($_POST['check_id'])){
		if($_POST['action']=="trash" || $_POST['action1']=="trash"){
			foreach($_POST['check_id'] as $id){
				$wpdb->delete( 'tbl_language', array( 'language_id' => $id));
			}
		}
		
	}	
	
	
		if($_POST['filter_by']=="desc"){
			$order="desc";
		}else{
			$order="asc";
		}
		
		if(isset($_GET['sort'])){
			$sort=$_GET['sort'];
			$order=$sort;
			if($_GET['sort']=="desc"){
				$sort="asc";
				
			}else{
				$sort="desc";
			}
		}else{
			$sort="desc";
		}
		
		if($_POST['search']!==""){
			$serch='%'.$_POST['search'].'%';
		}else{
			$serch='%';
		}
	
	$languages = $wpdb->get_results( "select * from tbl_language where language like '".$serch."' order by language ".$order );
	$rowcount = $wpdb->num_rows;
?>
<div class="wrap">
<h1>Language <a href="admin.php?page=add_language" class="page-title-action">Add New</a></h1>
<form method="post">
	<ul class="subsubsub">
		<li class="all"><a href="edit.php?post_type=page" class="current">All <span class="count">(3)</span></a> |</li>
		<li class="publish"><a href="edit.php?post_status=publish&amp;post_type=page">Published <span class="count">(3)</span></a></li>
	</ul>
	<p class="search-box">
		<label class="screen-reader-text" for="post-search-input">Search Pages:</label>
		<input type="search" id="post-search-input" name="search" value="">
		<input type="submit" id="search-submit" name="btn_serach" class="button" value="Search Language">
	</p>

<div class="tablenav top">
	
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-top" class="screen-reader-text">Select bulk action</label>
		<select name="action" id="bulk-action-selector-top">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction" class="button action" value="Apply">
	</div>
	<div class="alignleft actions">
		<label for="filter-by-date" class="screen-reader-text">Filter by date</label>
		<select name="filter_by">
			<option selected value="asc">Name Ascending</option>
			<option value="desc">Name descending</option>
		</select>
		<input type="submit" name="filter_action" id="post-query-submit" class="button" value="Filter">		
	</div>
	<div class="tablenav-pages one-page"><span class="displaying-num"><?php echo $rowcount; ?> items</span>
		<span class="pagination-links"><span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging"><span class="tablenav-paging-text"> of <span class="total-pages">1</span></span></span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span></span>
	</div>
	<br class="clear">
</div>

<table class="wp-list-table widefat fixed striped pages">
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=language&sort=<?php echo $sort; ?>">
					<span>Language</span><span class="sorting-indicator"></span>
				</a>
			</th>
		</tr>
	</thead>
	<tbody>
	<?php
		foreach($languages as $language){
	?>
		<tr id="post-2" class="iedit author-self level-0 post-2 type-page status-publish hentry">
			<th scope="row" class="check-column">
				<label class="screen-reader-text" for="cb-select-2">Select Sample Page</label>
				<input id="cb-select-2" type="checkbox" name="check_id[]" value="<?php echo $language->language_id; ?>">
				<div class="locked-indicator"></div>
			</th>
			<td class="title column-title has-row-actions column-primary page-title">
				<strong>
				<a class="row-title" href="#" >
					<?php echo $language->language; ?>
				</a>
				</strong>
				<div class="row-actions">
					<span class="edit">
						<a href="admin.php?page=add_language&edit=1&id=<?php echo $language->language_id; ?>" aria-label="Edit �Sample Page�">Edit</a> | 
					</span>
					<span class="trash">
						<a href="admin.php?page=language&delete=1&id=<?php echo $language->language_id; ?>" class="submitdelete" aria-label="Move �Sample Page� to the Trash" onclick="return confirm('Are you sure?');" >Trash</a> | 
					</span>
					
				</div>
			</td>
		</tr>
	<?php
		}
	?>
	</tbody>
	<thead>
		<tr>
			<td id="cb" class="manage-column column-cb check-column">
				<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
				<input id="cb-select-all-1" type="checkbox">
			</td>
			<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
				<a href="admin.php?page=language&sort=<?php echo $sort; ?>">
					<span>Language</span><span class="sorting-indicator"></span>
				</a>
			</th>
		</tr>
	</thead>
</table>
<div class="tablenav bottom">
	<div class="alignleft actions bulkactions">
		<label for="bulk-action-selector-bottom" class="screen-reader-text">Select bulk action</label>
		<select name="action1" id="bulk-action-selector-bottom">
			<option value="-1">Bulk Actions</option>
			<option value="trash">Move to Trash</option>
		</select>
		<input type="submit" name="delete" id="doaction2" class="button action" value="Apply">
	</div>
</form>
	<div class="alignleft actions"></div>
<div class="tablenav-pages one-page">
	<span class="displaying-num"><?php echo $rowcount; ?> items</span>
	<span class="pagination-links">
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="screen-reader-text">Current Page</span>
		<span id="table-paging" class="paging-input">
			<span class="tablenav-paging-text">1 of <span class="total-pages">1</span></span>
		</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
		<span class="tablenav-pages-navspan" aria-hidden="true">�</span>
	</span>
</div>
		<br class="clear">
</div>





</div>