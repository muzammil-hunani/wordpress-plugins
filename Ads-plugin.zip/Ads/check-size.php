<?php
if(isset($_POST['url'])){
	$position = $_POST['pos'];
	if($position == 1)
	{
		$require_size = array('728','120');
	}
	else if($position == 2)
	{
		$require_size = array('300','250');
	}
	else if($position == 3)
	{
		$require_size = array('300','600');
	}
	else if($position == 4)
	{
		$require_size = array('300','250');
	}
	else if($position == 5)
	{
		$require_size = array('300','600');
	}

	$size = array(getimagesize($_POST['url'])[0],getimagesize($_POST['url'])[1]);
	if($size == $require_size)
	{
		echo 0;
	} else {
		echo 1;
	} 

}
?>